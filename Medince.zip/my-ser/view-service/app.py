from flask import Flask, render_template, jsonify, redirect, url_for
import sqlite3

app = Flask(__name__)

# DATABASE_SERVICE_URL is not needed for viewing from the local DB in this service
DATABASE_SERVICE_URL = 'http://database-service:5001'  # URL of the database service

# Initialize the database and ensure the table exists
def init_db():
    conn = sqlite3.connect('medicine.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS medicines (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            expiry_date TEXT NOT NULL,
            manufacture_date TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

@app.route('/')
def home():
    # Redirect to the view medicines page
    return redirect(url_for('view_medicines'))

@app.route('/view_medicines', methods=['GET'])
def view_medicines():
    # Connect to the local SQLite database
    conn = sqlite3.connect('medicine.db')
    cursor = conn.cursor()
    
    # Fetch the data from the medicines table
    cursor.execute("SELECT name, expiry_date, manufacture_date FROM medicines")
    medicines = cursor.fetchall()
    conn.close()

    # Return the rendered template with the medicines data
    return render_template('view_medicines.html', medicines=medicines)

if __name__ == '__main__':
    init_db()  # Ensure the DB is initialized and the table is created
    app.run(debug=True, host='0.0.0.0', port=5002)  # Running the View Service on port 5002
