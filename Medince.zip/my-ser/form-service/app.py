from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__)

DATABASE_SERVICE_URL = 'http://database-service:5001'  # URL of the database service

@app.route('/')
def index():
    return render_template('index.html')  # The form page for entering medicine details

@app.route('/submit', methods=['POST'])
def submit():
    medicine_name = request.form['medicine_name']
    expiry = request.form['expiry']
    manufacture = request.form['manufacture']

    # Send the data to the database service
    response = requests.post(f'{DATABASE_SERVICE_URL}/add_medicine', json={
        'medicine_name': medicine_name,
        'expiry': expiry,
        'manufacture': manufacture
    })

    if response.status_code == 201:
        return 'Medicine added successfully!'  # Success message
    else:
        return 'Error adding medicine.'  # Error message

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)  # Running the Form Service on port 5000
