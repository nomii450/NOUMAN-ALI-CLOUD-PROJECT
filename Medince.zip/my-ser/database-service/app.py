from flask import Flask, request, jsonify
import sqlite3

app = Flask(__name__)

# Database setup
def init_db():
    conn = sqlite3.connect('medicines.db')  # SQLite database for storing medicine data
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS medicine_inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            medicine_name TEXT,
            expiry TEXT,
            manufacture TEXT
        )
    ''')
    conn.commit()
    conn.close()

@app.route('/add_medicine', methods=['POST'])
def add_medicine():
    data = request.get_json()
    medicine_name = data['medicine_name']
    expiry = data['expiry']
    manufacture = data['manufacture']

    conn = sqlite3.connect('medicines.db')
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO medicine_inventory (medicine_name, expiry, manufacture)
        VALUES (?, ?, ?)
    ''', (medicine_name, expiry, manufacture))
    conn.commit()
    conn.close()

    return 'Medicine successfully added!', 201  # Successful addition message

@app.route('/view_medicines', methods=['GET'])
def view_medicines():
    conn = sqlite3.connect('medicines.db')
    cursor = conn.cursor()
    cursor.execute("SELECT medicine_name, expiry, manufacture FROM medicine_inventory")
    medicines = cursor.fetchall()
    conn.close()
    
    return jsonify([{'medicine_name': row[0], 'expiry': row[1], 'manufacture': row[2]} for row in medicines])  # Return medicines data as JSON

if __name__ == '__main__':
    init_db()  # Initialize the database when starting the service
    app.run(debug=True, host='0.0.0.0', port=5001)  # Running the Database Service on port 5001
